package dev.ozeryn;

import dev.ozeryn.core.Module;
import dev.ozeryn.core.Modules;
import dev.ozeryn.gui.ClickGui;
import dev.ozeryn.modules.Watermark;
import net.fabricmc.api.ClientModInitializer;
import net.fabricmc.fabric.api.client.event.lifecycle.v1.ClientTickEvents;
import net.fabricmc.fabric.api.client.rendering.v1.HudRenderCallback;
import net.fabricmc.fabric.api.client.rendering.v1.WorldRenderEvents;
import net.fabricmc.fabric.api.client.screen.v1.ScreenEvents;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.gui.screen.ChatScreen;
import net.minecraft.client.util.InputUtil;
import org.lwjgl.glfw.GLFW;

public class Ozeryn implements ClientModInitializer {
    boolean wasDown;

    @Override
    public void onInitializeClient() {
        Modules.init();

        ClientTickEvents.END_CLIENT_TICK.register(mc -> {
            boolean down = mc.getWindow() != null && InputUtil.isKeyPressed(mc.getWindow().getHandle(), GLFW.GLFW_KEY_RIGHT_SHIFT);
            if (down && !wasDown && mc.currentScreen == null && mc.player != null) mc.setScreen(new ClickGui());
            wasDown = down;
            for (Module m : Modules.all) {
                if (m.enabled || m == Watermark.I) m.onTick();
            }
        });

        HudRenderCallback.EVENT.register((ctx, delta) -> {
            if (MinecraftClient.getInstance().options.hudHidden) return;
            for (Module m : Modules.all) if (m.enabled) m.onHud(ctx, delta);
        });

        WorldRenderEvents.AFTER_TRANSLUCENT.register(ctx -> {
            for (Module m : Modules.all) if (m.enabled) m.onWorld(ctx);
        });

        ScreenEvents.AFTER_INIT.register((client, screen, w, h) -> {
            if (screen instanceof ChatScreen)
                ScreenEvents.afterRender(screen).register((s, ctx, mx, my, d) -> Watermark.I.chatDrag(mx, my));
        });
    }
}
