package dev.ozeryn.util;

import net.minecraft.entity.Entity;
import net.minecraft.util.math.Box;
import net.minecraft.util.math.MathHelper;
import net.minecraft.util.math.Vec3d;

import java.util.Random;

public final class Rot {
    public static final Random RND = new Random();

    public static double g(double s) { return RND.nextGaussian() * s; }
    public static double sat(double x, double c) { return c * Math.tanh(x / c); }

    /** {yaw, pitch} from one point to another. */
    public static float[] to(Vec3d from, Vec3d to) {
        double dx = to.x - from.x, dy = to.y - from.y, dz = to.z - from.z;
        double h = Math.sqrt(dx * dx + dz * dz);
        float yaw = (float) MathHelper.wrapDegrees(Math.toDegrees(Math.atan2(dz, dx)) - 90.0);
        float pitch = (float) (-Math.toDegrees(Math.atan2(dy, h)));
        return new float[]{yaw, pitch};
    }

    public static float approach(float cur, float tgt, float max) {
        float d = MathHelper.wrapDegrees(tgt - cur);
        return cur + MathHelper.clamp(d, -max, max);
    }

    public static Vec3d clampToBox(Vec3d p, Box b) {
        return new Vec3d(MathHelper.clamp(p.x, b.minX, b.maxX), MathHelper.clamp(p.y, b.minY, b.maxY), MathHelper.clamp(p.z, b.minZ, b.maxZ));
    }

    public static double dist(Vec3d p, Box b) {
        return p.distanceTo(clampToBox(p, b));
    }

    /** Closest hitbox point horizontally, at a fixed height fraction. */
    public static Vec3d nearest(Vec3d eye, Box b, double yFrac) {
        double y = b.minY + (b.maxY - b.minY) * yFrac;
        return new Vec3d(MathHelper.clamp(eye.x, b.minX, b.maxX), y, MathHelper.clamp(eye.z, b.minZ, b.maxZ));
    }

    public static Vec3d motion(Entity e) {
        return new Vec3d(e.getX() - e.prevX, e.getY() - e.prevY, e.getZ() - e.prevZ);
    }

    public static Vec3d lerpPos(Entity e, float d) {
        return new Vec3d(MathHelper.lerp(d, e.prevX, e.getX()), MathHelper.lerp(d, e.prevY, e.getY()), MathHelper.lerp(d, e.prevZ, e.getZ()));
    }
}
