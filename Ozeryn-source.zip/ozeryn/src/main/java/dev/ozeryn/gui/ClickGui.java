package dev.ozeryn.gui;

import dev.ozeryn.core.*;
import dev.ozeryn.core.Module;
import dev.ozeryn.util.R2;
import net.minecraft.client.gui.DrawContext;
import net.minecraft.client.gui.screen.Screen;
import net.minecraft.text.Text;
import org.lwjgl.glfw.GLFW;

import java.util.ArrayList;
import java.util.List;

public class ClickGui extends Screen {
    static class Hit {
        int x, y, w, h; Runnable left, right; Setting.Num slider;
        Hit(int x, int y, int w, int h) { this.x = x; this.y = y; this.w = w; this.h = h; }
        boolean in(double mx, double my) { return mx >= x && mx <= x + w && my >= y && my <= y + h; }
    }

    final List<Hit> hits = new ArrayList<>();
    Hit dragging;

    public ClickGui() { super(Text.literal("Ozeryn")); }

    @Override public boolean shouldPause() { return false; }

    @Override
    public void render(DrawContext c, int mx, int my, float delta) {
        hits.clear();
        c.fill(0, 0, width, height, 0x88050508);
        Category[] cats = Category.values();
        int pw = 128, gap = 8;
        int total = cats.length * pw + (cats.length - 1) * gap;
        int x0 = (width - total) / 2;
        int accent = Theme.argb(255);

        for (int i = 0; i < cats.length; i++) {
            int x = x0 + i * (pw + gap), y = 28;
            R2.rrect(c, x, y, pw, 22, 6, 0xF0101016);
            R2.text(c, cats[i].label, x + 8, y + 6, accent);
            y += 24;
            for (Module m : Modules.of(cats[i])) {
                int rh = 18;
                int bg = m.enabled ? R2.alpha(Theme.rgb(), 70) : 0xD0121218;
                R2.rrect(c, x, y, pw, rh, 4, bg);
                R2.text(c, m.name, x + 8, y + 4, m.enabled ? 0xFFFFFFFF : 0xFF9A9AA8);
                if (!m.settings.isEmpty()) R2.text(c, m.open ? "-" : "+", x + pw - 12, y + 4, 0xFF70707E);
                Hit h = new Hit(x, y, pw, rh);
                final Module fm = m;
                h.left = fm::toggle; h.right = () -> fm.open = !fm.open;
                hits.add(h);
                y += rh + 2;
                if (m.open) {
                    for (Setting s : m.settings) {
                        if (!s.visible.getAsBoolean()) continue;
                        int sh = 16;
                        R2.rrect(c, x + 4, y, pw - 8, sh, 3, 0xC00C0C11);
                        Hit sh2 = new Hit(x + 4, y, pw - 8, sh);
                        if (s instanceof Setting.Bool b) {
                            R2.text(c, b.name, x + 10, y + 3, 0xFFC4C4D0);
                            int px = x + pw - 28;
                            R2.rrect(c, px, y + 4, 18, 8, 4, b.value ? accent : 0xFF2A2A34);
                            R2.rrect(c, b.value ? px + 10 : px + 1, y + 5, 6, 6, 3, 0xFFFFFFFF);
                            sh2.left = () -> b.value = !b.value;
                        } else if (s instanceof Setting.Num n) {
                            String v = n.step >= 1 ? String.valueOf((int) n.value) : String.format("%.1f", n.value);
                            R2.text(c, n.name, x + 10, y + 1, 0xFFC4C4D0);
                            R2.text(c, v, x + pw - 12 - R2.w(v), y + 1, 0xFF8A8A98);
                            int bx = x + 10, bw = pw - 28;
                            R2.rrect(c, bx, y + 12, bw, 2, 1, 0xFF2A2A34);
                            int fw = (int) (bw * (n.value - n.min) / (n.max - n.min));
                            R2.rrect(c, bx, y + 12, Math.max(2, fw), 2, 1, accent);
                            sh2.slider = n; sh2.x = bx - 2; sh2.w = bw + 4;
                        } else if (s instanceof Setting.Mode md) {
                            R2.text(c, md.name, x + 10, y + 3, 0xFFC4C4D0);
                            R2.text(c, md.get(), x + pw - 12 - R2.w(md.get()), y + 3, accent);
                            sh2.left = () -> md.next(1); sh2.right = () -> md.next(-1);
                        }
                        hits.add(sh2);
                        y += sh + 1;
                    }
                    y += 2;
                }
            }
        }

        // theme colours, bottom centre
        int n = Theme.COLORS.length, sw = 16, sg = 7;
        int tw = n * sw + (n - 1) * sg, tx = (width - tw) / 2, ty = height - 34;
        R2.rrect(c, tx - 12, ty - 8, tw + 24, sw + 16, 8, 0xE0101016);
        for (int i = 0; i < n; i++) {
            int x = tx + i * (sw + sg);
            if (i == Theme.index) R2.rrect(c, x - 2, ty - 2, sw + 4, sw + 4, 9, 0xFFFFFFFF);
            R2.rrect(c, x, ty, sw, sw, 8, 0xFF000000 | Theme.COLORS[i]);
            Hit h = new Hit(x, ty, sw, sw);
            final int idx = i;
            h.left = () -> Theme.index = idx;
            hits.add(h);
        }
        String hint = "Right Shift: close   |   Left click: toggle   |   Right click: settings";
        R2.text(c, hint, (width - R2.w(hint)) / 2, height - 12, 0xFF70707E);
    }

    void setSlider(Hit h, double mx) {
        double t = (mx - h.x - 2) / (double) (h.w - 4);
        t = Math.max(0, Math.min(1, t));
        h.slider.set(h.slider.min + t * (h.slider.max - h.slider.min));
    }

    @Override
    public boolean mouseClicked(double mx, double my, int button) {
        for (Hit h : hits) {
            if (!h.in(mx, my)) continue;
            if (h.slider != null && button == 0) { dragging = h; setSlider(h, mx); return true; }
            if (button == 0 && h.left != null) h.left.run();
            else if (button == 1 && h.right != null) h.right.run();
            return true;
        }
        return super.mouseClicked(mx, my, button);
    }

    @Override
    public boolean mouseDragged(double mx, double my, int button, double dx, double dy) {
        if (dragging != null) { setSlider(dragging, mx); return true; }
        return super.mouseDragged(mx, my, button, dx, dy);
    }

    @Override
    public boolean mouseReleased(double mx, double my, int button) {
        dragging = null;
        return super.mouseReleased(mx, my, button);
    }

    @Override
    public boolean keyPressed(int key, int sc, int mod) {
        if (key == GLFW.GLFW_KEY_RIGHT_SHIFT) { close(); return true; }
        return super.keyPressed(key, sc, mod);
    }
}
