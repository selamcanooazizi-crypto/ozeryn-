package dev.ozeryn.core;
public enum Category {
    COMBAT("Combat"), RENDER("Render"), MISC("Misc"), CLIENT("Client");
    public final String label;
    Category(String l) { label = l; }
}
