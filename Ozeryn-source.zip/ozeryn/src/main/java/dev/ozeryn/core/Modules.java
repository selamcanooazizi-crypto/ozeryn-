package dev.ozeryn.core;

import dev.ozeryn.modules.*;

import java.util.ArrayList;
import java.util.List;

public final class Modules {
    public static final List<Module> all = new ArrayList<>();

    public static void init() {
        all.add(new Aura());
        all.add(new ElytraTarget());
        all.add(new TargetEsp());
        all.add(new Watermark());
        all.add(new ChinaHat());
        all.add(new CustomSky());
        all.add(new FpsBoost());
        all.add(new ArrayListHud());
        all.add(new Fullbright());
        all.add(new AutoSprint());
        all.add(new RotationMod());
        all.add(new ClientLook());
    }

    public static List<Module> of(Category c) {
        List<Module> l = new ArrayList<>();
        for (Module m : all) if (m.category == c) l.add(m);
        return l;
    }
}
