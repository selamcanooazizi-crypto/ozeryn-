package dev.ozeryn.modules;

import dev.ozeryn.core.*;
import dev.ozeryn.core.Module;
import dev.ozeryn.util.R2;
import net.minecraft.client.gui.DrawContext;
import org.lwjgl.glfw.GLFW;

public class Watermark extends Module {
    public static Watermark I;
    public final Setting.Bool showBps = add(new Setting.Bool("BPS", true));
    public final Setting.Bool showFps = add(new Setting.Bool("FPS", true));
    public final Setting.Bool showName = add(new Setting.Bool("Name", true));
    public final Setting.Bool useTheme = add(new Setting.Bool("Theme Color", true));
    public final Setting.Num alpha = add(new Setting.Num("Opacity", 170, 0, 255, 5));

    public int x = 6, y = 6;
    public double bps;
    double px, pz; boolean hasPos;
    int bx, by, bw, bh;
    boolean dragging; int offX, offY;

    public Watermark() { super("Watermark", Category.RENDER); I = this; enabled = true; }

    @Override
    public void onTick() {
        if (mc.player == null) { hasPos = false; return; }
        double cx = mc.player.getX(), cz = mc.player.getZ();
        if (hasPos) {
            double v = Math.hypot(cx - px, cz - pz) * 20.0;
            bps += (v - bps) * 0.25;
        }
        px = cx; pz = cz; hasPos = true;
    }

    String body() {
        StringBuilder sb = new StringBuilder();
        if (showName.value && mc.player != null) sb.append(mc.player.getName().getString());
        if (showFps.value) { if (sb.length() > 0) sb.append("  |  "); sb.append(net.minecraft.client.MinecraftClient.getInstance().getCurrentFps()).append(" fps"); }
        if (showBps.value) { if (sb.length() > 0) sb.append("  |  "); sb.append(String.format("%.1f", bps)).append(" bps"); }
        return sb.toString();
    }

    @Override
    public void onHud(DrawContext c, float delta) {
        String title = "Ozeryn";
        String body = body();
        int accent = useTheme.value ? Theme.argb(255) : 0xFFFFFFFF;
        int tw = R2.w(title), bwid = body.isEmpty() ? 0 : R2.w(body);
        bw = 10 + tw + (bwid > 0 ? 12 + bwid : 0) + 6;
        bh = 20;
        bx = x; by = y;
        R2.rrect(c, x, y, bw, bh, 5, ((int) alpha.value << 24) | 0x0A0A0E);
        R2.rrect(c, x, y + 4, 2, bh - 8, 1, accent);
        R2.text(c, title, x + 8, y + 5, accent);
        if (bwid > 0) R2.text(c, body, x + 8 + tw + 12, y + 5, 0xFFD0D0DA);
    }

    /** Called every frame while the chat screen is open; left-drag moves the watermark. */
    public void chatDrag(int mx, int my) {
        boolean down = GLFW.glfwGetMouseButton(mc.getWindow().getHandle(), GLFW.GLFW_MOUSE_BUTTON_LEFT) == GLFW.GLFW_PRESS;
        if (!down) { dragging = false; return; }
        if (!dragging && mx >= bx && mx <= bx + bw && my >= by && my <= by + bh) {
            dragging = true; offX = mx - x; offY = my - y;
        }
        if (dragging) {
            x = Math.max(0, Math.min(mc.getWindow().getScaledWidth() - bw, mx - offX));
            y = Math.max(0, Math.min(mc.getWindow().getScaledHeight() - bh, my - offY));
        }
    }
}
