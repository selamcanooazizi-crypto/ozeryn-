package dev.ozeryn.modules;

import dev.ozeryn.core.*;
import dev.ozeryn.core.Module;
import dev.ozeryn.util.Rot;
import net.minecraft.client.network.ClientPlayerEntity;

public class RotationMod extends Module {
    public static RotationMod I;
    public final Setting.Mode mode = add(new Setting.Mode("Mode", "Free", "Focus"));

    public RotationMod() { super("Rotation", Category.CLIENT); I = this; }

    public boolean focus() { return mode.is("Focus"); }

    @Override
    public void onTick() {
        ClientPlayerEntity p = mc.player;
        if (p == null || !Aura.I.enabled || Aura.I.target == null || p.isFallFlying()) return;
        if (!focus()) return; // Free: camera/movement direction is yours, Aura does not drag it
        boolean moving = mc.options.forwardKey.isPressed() || mc.options.backKey.isPressed()
                || mc.options.leftKey.isPressed() || mc.options.rightKey.isPressed();
        if (!moving) return;
        float[] r = Rot.to(p.getEyePos(), Aura.I.target.getPos().add(0, Aura.I.target.getHeight() * 0.5, 0));
        p.setYaw(Rot.approach(p.getYaw(), r[0], 35f));
    }
}
