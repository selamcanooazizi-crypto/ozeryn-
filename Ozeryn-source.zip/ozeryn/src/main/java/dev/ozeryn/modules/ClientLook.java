package dev.ozeryn.modules;

import dev.ozeryn.core.*;
import dev.ozeryn.core.Module;

/** When on, Aura rotates your real camera (visible). When off, rotation is silent (packet only). */
public class ClientLook extends Module {
    public static ClientLook I;
    public ClientLook() { super("ClientLook", Category.CLIENT); I = this; }
}
