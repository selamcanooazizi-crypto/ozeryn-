package dev.ozeryn.modules;

import dev.ozeryn.core.*;
import dev.ozeryn.core.Module;
import dev.ozeryn.util.R3;
import dev.ozeryn.util.Rot;
import net.fabricmc.fabric.api.client.rendering.v1.WorldRenderContext;
import net.minecraft.client.network.ClientPlayerEntity;
import net.minecraft.entity.LivingEntity;
import net.minecraft.item.Items;
import net.minecraft.util.Hand;
import net.minecraft.util.math.Vec3d;

public class ElytraTarget extends Module {
    public static ElytraTarget I;

    public final Setting.Mode mode = add(new Setting.Mode("Mode", "Silent", "Normal"));
    public final Setting.Bool legit = add(new Setting.Bool("Legit Fireworks", true));
    public final Setting.Bool autoFw = add(new Setting.Bool("Auto Firework", true));
    public final Setting.Num predict = add(new Setting.Num("Predict", 2, 0, 5, 0.5));
    public final Setting.Num overshoot = add(new Setting.Num("Overshoot", 0, 0, 6, 0.5));

    Vec3d ghost;
    int fwCd;

    public ElytraTarget() { super("Elytra Target", Category.COMBAT); I = this; }

    @Override public void onDisable() { ghost = null; }

    public boolean isActive(ClientPlayerEntity p) {
        return enabled && Aura.I.enabled && p.isFallFlying();
    }

    Vec3d ghostFor(LivingEntity t) {
        Vec3d v = Rot.motion(t);
        Vec3d g = t.getPos().add(0, t.getHeight() * 0.5, 0).add(v.multiply(predict.value * 4.0));
        if (overshoot.value > 0) {
            Vec3d dir = v.lengthSquared() > 1e-4 ? v.normalize() : Vec3d.fromPolar(0, mc.player.getYaw());
            g = g.add(dir.multiply(overshoot.value));
        }
        return g;
    }

    public void tick(ClientPlayerEntity p, LivingEntity t) {
        Aura a = Aura.I;
        if (fwCd > 0) fwCd--;
        Vec3d eye = p.getEyePos();
        double dT = Rot.dist(eye, t.getBoundingBox());
        double speed = p.getVelocity().length();

        boolean justFw = false;
        if (autoFw.value && fwCd <= 0 && speed < 1.6) {
            justFw = useFirework(p);
            if (justFw) fwCd = 12;
        }

        ghost = t.isFallFlying() && predict.value > 0 ? ghostFor(t) : null;
        boolean close = dT < 5.0;
        Vec3d steer;
        if (mode.is("Normal") && close) steer = Rot.nearest(eye, t.getBoundingBox(), 0.6);
        else steer = (ghost != null ? ghost : t.getPos().add(0, t.getHeight() * 0.5, 0));
        float[] r = Rot.to(eye, steer);
        p.setYaw(Rot.approach(p.getYaw(), r[0], 45f));
        p.setPitch(Rot.approach(p.getPitch(), r[1], 35f));
        a.rotYaw = p.getYaw(); a.rotPitch = p.getPitch();

        boolean cdOk = (legit.value && justFw) || p.getAttackCooldownProgress(0.5f) >= 0.9f;
        if (dT <= a.range.value && t.hurtTime == 0 && cdOk) {
            Vec3d point = a.pointFor(eye, t);
            float[] hit = Rot.to(eye, point);
            a.attack(t, hit[0], hit[1]);
        }
    }

    boolean useFirework(ClientPlayerEntity p) {
        if (mc.interactionManager == null) return false;
        if (p.getOffHandStack().isOf(Items.FIREWORK_ROCKET)) {
            mc.interactionManager.interactItem(p, Hand.OFF_HAND);
            return true;
        }
        int slot = -1;
        for (int i = 0; i < 9; i++) if (p.getInventory().getStack(i).isOf(Items.FIREWORK_ROCKET)) { slot = i; break; }
        if (slot < 0) return false;
        int old = p.getInventory().selectedSlot;
        p.getInventory().selectedSlot = slot;
        mc.interactionManager.interactItem(p, Hand.MAIN_HAND);
        p.getInventory().selectedSlot = old;
        return true;
    }

    @Override
    public void onWorld(WorldRenderContext c) {
        if (ghost == null || !Aura.I.enabled || Aura.I.target == null || mc.player == null || !mc.player.isFallFlying()) return;
        R3.begin();
        R3.orb(c.matrixStack(), c.camera(), ghost, 0.55f, 0x70B0B0B8);
        R3.orb(c.matrixStack(), c.camera(), ghost, 0.3f, 0x90C8C8D0);
        R3.end();
    }
}
